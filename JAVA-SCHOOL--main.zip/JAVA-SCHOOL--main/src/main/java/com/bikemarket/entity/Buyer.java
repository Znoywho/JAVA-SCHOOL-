package com.bikemarket.entity;

import com.bikemarket.enums.Role;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// NOTE: Buyer inherits from User by joining the `TABLE`
public class Buyer extends User {

  @OneToOne(mappedBy = "buyer", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = false)
  private Cart cart;

  public Buyer(String name, String email, String phone, String password) {
    super(name, email, phone, password, Role.BUYER);
  }

}
